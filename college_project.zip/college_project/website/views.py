from django.shortcuts import render

def index(request):
    return render(request, 'website/index.html')

def about(request):
    return render(request, 'website/about.html')

def contact(request):
    return render(request, 'website/contact.html')

def jobs(request):
    return render(request, 'website/job-listings.html')

def post_job(request):
    return render(request, 'website/post-job.html')


